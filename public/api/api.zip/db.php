<?php
// db.php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=UTF-8");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}
  
$host = "localhost";
$db_name = "omsai_db"; 
$username = "e3u1qog8gwl5"; 
$password = "A65J2@Ort%bb";

date_default_timezone_set('Asia/Kolkata');

try {
    $conn = new PDO("mysql:host=" . $host . ";dbname=" . $db_name, $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->exec("set names utf8");
    $conn->exec("SET time_zone = '+05:30'");
} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database Connection Failed: " . $exception->getMessage()]);
    exit();
}
?>
